fetch("https://jsonblob.com/api/jsonBlob/1351950892655632384/")
  .then((response) => response.json())
  .then((data) => renderMovies(data.movies))
  .catch((error) => console.error("Fetch error:", error));

const target = document.querySelector(".main-container");

function renderMovies(movies) {
  function formatSrc(src) {
    return src.endsWith("/") ? src.slice(0, -1) : src;
  }
  movies.forEach((movie) => {
    let newCard = document.createElement("div");
    newCard.classList.add("movie-container");
    newCard.setAttribute("title", `${movie.title}`);
    movieimg = formatSrc(movie.img);
    newCard.innerHTML = `
    <div class="img-container"><img src = ${movieimg} /></div>
    
    <h4>${movie.title}</h4>
    <p class = "description">Year: ${movie.year}</p>
    <p class = "description">Genre: ${movie.genre[0]}</p>
    <p class = "description">IMDb rating: ${movie.imdb_rating}</p>
    `;
    /*console.log(target);*/
    target.appendChild(newCard);
  });
}

const searchButton = document.querySelector(".search-button");
let inputText;
let movielist;
let movieDiv;
// console.log(searchButton);
searchButton.addEventListener("click", function () {
  inputText = document.querySelector(".search-text").value;
  let movielist = document.querySelectorAll(".movie-container");
  movielist.forEach((movie) => {
    console.log("klik");
    console.log(movie);
    // movieDiv = movie.firstChild(".movie-container");
    console.log(movieDiv);
    if (
      movie
        .getAttribute("title")
        .toLowerCase()
        .includes(inputText.toLowerCase()) ||
      inputText == ""
    )
      movie.classList.remove("hidden");
    else movie.classList.add("hidden");
  });
});
