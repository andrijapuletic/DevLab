let itemList = [];
const submitButton = document.querySelector(".submit");
const table = document.querySelector("tbody");
const searchbar = document.querySelector(".search-items");

submitButton.addEventListener("click", function () {
  let addInput = document.querySelector(".add-input").value;
  if (!addInput) return;

  itemList.push(addInput);

  let newRow = document.createElement("tr");
  newRow.innerHTML = `
    <td>
      <div class="td-container">${addInput}<div class="delete" row-id="${addInput}">X</div>
      </div>
    </td>
  `;
  table.appendChild(newRow);
  newRow.querySelector(".delete").addEventListener("click", function (e) {
    let rowId = this.getAttribute("row-id");
    itemList = itemList.filter((item) => item !== rowId);
    newRow.remove();
  });

  addInput = ""; //ne radi brisanje unosa nakon submit-a ????
});
let searchword;
let tableElements;
let str;
let trElement;
searchbar.addEventListener("keyup", function (e) {
  searchword = searchbar.value;
  tableElements = document.querySelectorAll(".td-container");
  /*trElement = tableElements.closest("tr");*/

  tableElements.forEach((element) => {
    trElement = element.closest("tr");
    if (element && element.textContent.includes(searchword)) {
      console.log(searchword, "<-", element.textContent);
      /*console.log("proba", element.getAttributeNames());*/
      if (trElement.classList.contains("hidden"))
        trElement.classList.remove("hidden");
    } else trElement.classList.add("hidden");
  });
});
