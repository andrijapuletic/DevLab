let itemList = [];
const submitButton = document.querySelector(".submit");
const table = document.querySelector("tbody");

submitButton.addEventListener("click", function () {
  let addInput = document.querySelector(".add-input").value;
  if (!addInput) return;

  itemList.push(addInput);

  let newRow = document.createElement("tr");
  newRow.innerHTML = `
    <td>
      <div class="td-container">
        ${addInput}
        <div class="delete" row-id="${addInput}">X</div>
      </div>
    </td>
  `;
  console.log(newRow);
  table.appendChild(newRow);
  newRow.querySelector(".delete").addEventListener("click", function () {
    let rowId = this.getAttribute("row-id");
    itemList = itemList.filter((item) => item !== rowId);
    newRow.remove();
  });
});
/// nisam stigao da odradim dio za pretrazivanje
